package com.semanticintelligence.app.service;

import com.semanticintelligence.app.common.Command;

public interface Si2DocNetworkMapService {

	Long getGraphIdByDocumentAndType(Command command);

}
