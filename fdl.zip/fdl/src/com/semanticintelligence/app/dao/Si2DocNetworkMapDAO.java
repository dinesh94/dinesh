package com.semanticintelligence.app.dao;

import com.semanticintelligence.app.common.Command;

public interface Si2DocNetworkMapDAO {

	Long getGraphIdByDocumentAndType(Command command);

}
