package com.rage.siapp.nlp.tools.network.graph.normalize;

public enum EntityType 
{
	PERSON,
	COMPANY,
	REGULATORY_BODY,
	TIME_PERIOD,
	RELATIONSHIP,
	GEOGRAPHY,
	NONE
}
