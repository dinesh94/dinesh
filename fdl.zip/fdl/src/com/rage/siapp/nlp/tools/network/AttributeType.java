package com.rage.siapp.nlp.tools.network;

public enum AttributeType
{
	INTENSITY,
	QUANTITY,
	TIME_PERIOD,
	LOCATION,
	NONE,
	PATH_NODE_ID,
	PATH_EDGE_ID
}
